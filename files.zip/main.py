"""
main.py
-------
Entry point. Run this file to see the full report.
Usage: python main.py
"""

from analyzer import analyse
from report import print_report

# Path to the CSV file (relative to where you run the script)
CSV_PATH = "data/sample_marks.csv"


def main():
    # Step 1: Read CSV and compute results
    results, subjects = analyse(CSV_PATH)

    # Step 2: Print the formatted report
    print_report(results, subjects)


# This block runs only when you execute main.py directly,
# not when it's imported as a module.
if __name__ == "__main__":
    main()
