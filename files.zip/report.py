"""
report.py
---------
Prints a clean, formatted result report to the terminal.
"""


def print_divider(char="-", width=65):
    """Utility: print a horizontal line."""
    print(char * width)


def print_report(results, subjects):
    """
    Takes the list of student result dicts (from analyzer.analyse)
    and prints a formatted report.
    """
    print_divider("=")
    print("         STUDENT RESULT ANALYZER — SUMMARY REPORT")
    print_divider("=")

    for student in results:
        print(f"\nStudent : {student['name']}")
        print(f"Status  : {student['status']}")
        print(f"SGPA    : {student['sgpa']}   |   Average %: {student['percentage']}%")
        print_divider()

        # Subject-wise breakdown
        print(f"{'Subject':<15} {'Marks':>6} {'Grade':>6}")
        print_divider("-", 30)
        for sub in subjects:
            marks = student["marks"][sub]
            grade = student["grades"][sub]
            print(f"{sub:<15} {marks:>6} {grade:>6}")

        print_divider()

    # ── Class-level stats ─────────────────────────────────────────────────────
    print("\n" + "=" * 65)
    print("                     CLASS STATISTICS")
    print("=" * 65)

    total_students = len(results)
    passed = sum(1 for s in results if s["status"] == "PASS")
    failed = total_students - passed
    avg_sgpa = round(sum(s["sgpa"] for s in results) / total_students, 2)
    topper = max(results, key=lambda s: s["percentage"])

    print(f"Total Students : {total_students}")
    print(f"Passed         : {passed}")
    print(f"Failed         : {failed}")
    print(f"Class Avg SGPA : {avg_sgpa}")
    print(f"Class Topper   : {topper['name']} ({topper['percentage']}%)")
    print_divider("=")

    # ── Per-subject averages ──────────────────────────────────────────────────
    print("\nSubject-wise Class Averages:")
    print_divider("-", 30)
    for sub in subjects:
        avg = round(sum(s["marks"][sub] for s in results) / total_students, 2)
        print(f"  {sub:<15} {avg}%")
    print_divider("=")
