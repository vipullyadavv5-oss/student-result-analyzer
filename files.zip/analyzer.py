"""
analyzer.py
-----------
Core logic: reads CSV, calculates grades, SGPA, and pass/fail for each student.
"""

import csv  # built-in Python module — no installation needed


# ── Grade boundaries (MU-style, you can adjust) ──────────────────────────────
def get_grade(marks):
    """Return letter grade and grade point for given marks (out of 100)."""
    if marks >= 90:
        return "O", 10       # Outstanding
    elif marks >= 80:
        return "A+", 9
    elif marks >= 70:
        return "A", 8
    elif marks >= 60:
        return "B+", 7
    elif marks >= 50:
        return "B", 6
    elif marks >= 40:
        return "C", 5        # Pass
    else:
        return "F", 0        # Fail


# ── Pass/Fail check ───────────────────────────────────────────────────────────
def is_pass(subject_marks):
    """
    A student passes only if they score >= 40 in ALL subjects.
    subject_marks: list of integers
    """
    return all(m >= 40 for m in subject_marks)


# ── SGPA calculation ──────────────────────────────────────────────────────────
def calculate_sgpa(subject_marks):
    """
    Simple SGPA: average of grade points across all subjects.
    (Assumes all subjects carry equal credit — fine for a beginner project.)
    """
    grade_points = [get_grade(m)[1] for m in subject_marks]
    return round(sum(grade_points) / len(grade_points), 2)


# ── Read CSV and analyse ──────────────────────────────────────────────────────
def analyse(filepath):
    """
    Reads the CSV file, processes each student row, and returns a list of dicts.
    Each dict has: name, marks (dict), total, percentage, grades, sgpa, status
    """
    results = []

    with open(filepath, newline="") as f:
        reader = csv.DictReader(f)          # first row becomes keys automatically
        subjects = reader.fieldnames[1:]    # skip 'Name' column

        for row in reader:
            name = row["Name"]

            # Convert mark strings to integers
            marks = {sub: int(row[sub]) for sub in subjects}
            mark_values = list(marks.values())

            total = sum(mark_values)
            percentage = round(total / len(subjects), 2)   # average %

            # Grade for each subject
            grades = {sub: get_grade(m)[0] for sub, m in marks.items()}

            sgpa = calculate_sgpa(mark_values)
            status = "PASS" if is_pass(mark_values) else "FAIL"

            results.append({
                "name":       name,
                "marks":      marks,
                "total":      total,
                "percentage": percentage,
                "grades":     grades,
                "sgpa":       sgpa,
                "status":     status,
            })

    return results, subjects
